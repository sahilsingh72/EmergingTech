<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class OneDriveService
{
    protected $clientId;
    protected $clientSecret;
    protected $tenantId;
    protected $redirectUri;
    protected $scopes;
    protected $tokenFile;

    public function __construct()
    {
        $this->clientId     = config('services.onedrive.client_id');
        $this->clientSecret = config('services.onedrive.client_secret');
        $this->tenantId     = config('services.onedrive.tenant_id');
        $this->redirectUri  = config('services.onedrive.redirect');
        $this->scopes       = 'offline_access Files.ReadWrite User.Read';
        $this->tokenFile    = storage_path('app/onedrive_token.json');
    }

    protected function getAuthority()
    {
        return "https://login.microsoftonline.com/{$this->tenantId}";
    }

    public function getAuthUrl()
    {
        return $this->getAuthority() . "/oauth2/v2.0/authorize?" . http_build_query([
            'client_id'     => $this->clientId,
            'response_type' => 'code',
            'redirect_uri'  => $this->redirectUri,
            'response_mode' => 'query',
            'scope'         => $this->scopes,
        ]);
    }

    public function getTokenFromCode($code)
    {
        $response = Http::asForm()->post($this->getAuthority() . '/oauth2/v2.0/token', [
            'client_id'     => $this->clientId,
            'client_secret' => $this->clientSecret,
            'code'          => $code,
            'redirect_uri'  => $this->redirectUri,
            'grant_type'    => 'authorization_code',
            'scope'         => $this->scopes,
        ]);

        $tokens = $response->json();

        file_put_contents($this->tokenFile, json_encode($tokens, JSON_PRETTY_PRINT));

        return $tokens;
    }

    protected function getAccessToken()
    {
        if (!file_exists($this->tokenFile)) {
            throw new \Exception("⚠️ Run login flow first.");
        }

        $tokens = json_decode(file_get_contents($this->tokenFile), true);

        // If token is still valid, reuse it
        if (isset($tokens['access_token'])) {
            return $tokens['access_token'];
        }

        // Refresh token if expired
        $response = Http::asForm()->post($this->getAuthority() . '/oauth2/v2.0/token', [
            'client_id'     => $this->clientId,
            'client_secret' => $this->clientSecret,
            'refresh_token' => $tokens['refresh_token'],
            'grant_type'    => 'refresh_token',
            'scope'         => $this->scopes,
        ]);

        $newTokens = $response->json();

        if (isset($newTokens['error'])) {
            throw new \Exception("Refresh failed: " . $newTokens['error_description']);
        }

        file_put_contents($this->tokenFile, json_encode($newTokens, JSON_PRETTY_PRINT));

        return $newTokens['access_token'];
    }

    /**
     * Upload a file directly (without saving locally)
     */
    public function uploadDirect($file, $folder = "MyMedia")
    {
        $accessToken = $this->getAccessToken();

        $filename = $file->getClientOriginalName(); // real filename
        $stream   = fopen($file->getRealPath(), 'r'); // stream tmp file

        $url = "https://graph.microsoft.com/v1.0/me/drive/root:/$folder/$filename:/content";

        $response = Http::withHeaders([
            'Authorization' => "Bearer {$accessToken}",
            'Content-Type'  => $file->getMimeType(),
        ])->send('PUT', $url, [
            'body' => $stream,
        ]);

        fclose($stream);

        if ($response->successful()) {
            return "✅ Uploaded: {$filename} → {$folder}/";
        }

        return "❌ Upload failed: " . $response->body();
    }
}
